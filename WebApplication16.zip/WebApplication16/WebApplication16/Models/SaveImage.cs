﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace WebApplication16.Models
{
    public class SaveImage:ISaveImage
    {
        private IWebHostEnvironment host = null;
        private const string upload_folder = "Previews";
        //******************************************************************************************
        public SaveImage(IWebHostEnvironment env)
        {
            this.host = env;
        }
        //******************************************************************************************
        void ISaveImage.Delete(string filename)
        {
            try
            {
                string fname = string.Format("{0}/{1}",this.host.WebRootPath, filename);
                if (File.Exists(fname))
                {
                    File.Delete(fname);        
                }
            }
            catch
            { 
            }
        }
        //******************************************************************************************
        string ISaveImage.Upload(IFormFile uploader)
        {
            string guid_name = (this as ISaveImage).SuggestFileName(uploader.FileName);
            string save_as = (this as ISaveImage).AbsoluteFileName(Path.Combine(this.host.WebRootPath, upload_folder),guid_name);
            using (Stream fs = File.OpenWrite(save_as))
            {
                uploader.CopyTo(fs);
            }
            return guid_name;
        }
        //******************************************************************************************
        string ISaveImage.SuggestFileName(string input_file)
        {

            string result = string.Format("{0}{1}",
                Guid.NewGuid().ToString(),
                Path.GetExtension(input_file)
                );
            return result;
        }
        //******************************************************************************************
        string ISaveImage.ReadUploadedFileName(string input_file)
        {
            string result = string.Format("/{0}/{1}", upload_folder, input_file);
            
            return result;
        }
        //******************************************************************************************
        string ISaveImage.AbsoluteFileName(string directory,string input_file)
        {
            
            string result = Path.Combine(directory, input_file);
            return result;

        }
        //******************************************************************************************

    }


}
