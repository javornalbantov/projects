﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public static class DecimalExtension
    {
        public static string StaticCurrency(this decimal? key)
        {
            string result = $"{key} {consts.BgLev}";
            return result;
        }

        public static string StaticCurrency(this decimal key)
        {
            string result = $"{key} {consts.BgLev}";
            return result;
        }
    }
}
