﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;


namespace WebApplication16.Models
{
    public class SessionReader: ISessionReader
    {
        private const string SESSION_KEY_SHOP_CARD = "ShopCard";
        private IHttpContextAccessor http = null;
        private SportStoreApplicationContext context_database = null;
        private UserManager<AppUser> user_manager = null;
        //*****************************************************************************************************************
        public SessionReader(IHttpContextAccessor context, SportStoreApplicationContext db,UserManager<AppUser> aUserManager)
        {
            this.http = context;
            this.context_database = db;
            this.user_manager = aUserManager;
        }
        //*****************************************************************************************************************
        bool ISessionReader.Empty()
        {
            return this.GetSession().Empty();
        }
        //*****************************************************************************************************************
        decimal ISessionReader.Total()
        {
            return this.GetSession().Total();
        }
        //*****************************************************************************************************************
        void ISessionReader.Remove(int product_id)
        {
            IListOrderedItems list = this.GetSession();
            list.Remove(product_id);
            this.UpdateSession(list);

        }
        //*****************************************************************************************************************
        void ISessionReader.Insert(int product_id, int quantity)
        {
            IListOrderedItems list = this.GetSession();
            Products db_product = this.context_database.Products.Include(product => product.ProductImages).
                Where(x => x.Id == product_id).First();
            ProductImages product_images = db_product.ProductImages.First();
            list.Insert(product_id, db_product.Price, db_product.Pname, quantity, product_images.PreviewFile);
            this.UpdateSession(list);
        }
        //*****************************************************************************************************************
        void ISessionReader.ClearAll()
        {
            IListOrderedItems list = this.GetSession();
            list.ClearAll();
            this.UpdateSession(list);
            this.http.HttpContext.Session.Clear();
        }
        //*****************************************************************************************************************
        void ISessionReader.Update(int product_id, int quantity)
        {
            IListOrderedItems list = this.GetSession();
            list.Update(product_id, quantity);
            this.UpdateSession(list);
        }
        //*****************************************************************************************************************
        async Task ISessionReader.Checkout()
        {
            AppUser current_user = await this.user_manager.GetUserAsync(this.http.HttpContext.User);

            IEnumerable<UserOrderedItem> products = (this as ISessionReader).Show();


            Orders item = new Orders()
            {
                Orderdate = DateTime.Now,
                Userid = current_user.Id,
                OrderedProducts =
                (from x in products
                 select new OrderedProducts()
                 {
                     ProductId = x.ProductID,
                     Quantity = x.Quantity
                 }).ToList()
            };
            (this as ISessionReader).ClearAll();

            this.context_database.Orders.Add(item);
            this.context_database.SaveChanges();
        }
        //*****************************************************************************************************************
        IEnumerable<UserOrderedItem> ISessionReader.Show()
        {
            IListOrderedItems list = this.GetSession();
            return list.Show();
        }
        //*****************************************************************************************************************
        private IListOrderedItems GetSession()
        {
            IListOrderedItems result = null;

            if (this.http.HttpContext.Session.Get(SESSION_KEY_SHOP_CARD) == null)
            {
                result = new ListOrderedItems();
                this.UpdateSession(result);
            }
            else
            {
                byte[] byte_list = this.http.HttpContext.Session.Get(SESSION_KEY_SHOP_CARD);
                result = this.FromByteArray(byte_list);
            }

            return result;
        }
        //*****************************************************************************************************************
        private void UpdateSession(IListOrderedItems sender)
        {
            byte[] byte_list = this.ToByteArray(sender);
            this.http.HttpContext.Session.Set(SESSION_KEY_SHOP_CARD, byte_list);
        }
        //*****************************************************************************************************************
        private IListOrderedItems FromByteArray(byte[] list)
        {
            IListOrderedItems result = null;
            if (list != null)
            {
                using (var memStream = new MemoryStream(list))
                {
                    BinaryFormatter binForm = new BinaryFormatter();

                    result = binForm.Deserialize(memStream) as IListOrderedItems;

                }
            }
            return result;
        }

        //*****************************************************************************************************************
        private byte[] ToByteArray(IListOrderedItems sender)
        {
            BinaryFormatter bf = new BinaryFormatter();
            using (var ms = new MemoryStream())
            {
                bf.Serialize(ms, sender);
                return ms.ToArray();
            }
        }
        
        //*****************************************************************************************************************
    }
}
