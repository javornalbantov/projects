﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public class CategoryManager : ICategoryManager
    {
        private SportStoreApplicationContext context = null;
        //********************************************************************************************************
        public CategoryManager(SportStoreApplicationContext db)
        {
            this.context = db;
        }
        //********************************************************************************************************
        Category ICategoryManager.Empty()
        {
            Category result = new Category
            {
                Id = 0,
                CategoryName = ""
            };
            return result;
        }
        //********************************************************************************************************
        IEnumerable<Category> ICategoryManager.List()
        {
            return this.context.Category.OrderBy(x => x.CategoryName);
        }
        //********************************************************************************************************
        void ICategoryManager.AddCategory(Category sender)
        {
            Category item = new Category()
            {
                CategoryName = sender.CategoryName.Trim()
            };
            this.context.Category.Add(item);
            this.context.SaveChanges();
        }
        //********************************************************************************************************
        void ICategoryManager.DeleteCategory(int id)
        {
            bool ok = this.context.Category.Any(x => x.Id == id);
            if (ok)
            {
                var element = this.context.Category.Where(x => x.Id == id).First();
                this.context.Category.Remove(element);
                this.context.SaveChanges();
            }
        }
        //********************************************************************************************************
        void ICategoryManager.EditCategory(Category sender)
        {
            bool ok = this.context.Category.Any(x => x.Id == sender.Id);
            if (ok)
            {
                var element = this.context.Category.Where(x => x.Id == sender.Id).First();
                element.CategoryName = sender.CategoryName;
                this.context.SaveChanges();
            }
        }
        //********************************************************************************************************
        Category ICategoryManager.FindById(int id)
        {
            Category result = null;
            bool ok = this.context.Category.Any(x => x.Id == id);
            if (ok)
            {
                result
                     =
                     this.context.Category.Where(x => x.Id == id).First();
            }
            return result;
        }
        //********************************************************************************************************
    }
}
