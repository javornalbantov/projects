﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public static class IdentityResultExt
    {
        public static void AddMultipleErrors(this ModelStateDictionary sender,IEnumerable<IdentityError> errors)
        {
            foreach (var k in errors)
            {
                sender.AddModelError("", k.Description);
            }
        }
    }
}
