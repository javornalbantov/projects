﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class ExtractRoles
    {
        
        //********************************************************************
        private List<UserRoleItem> Items = null;
        public IEnumerable<UserRoleItem> GetItems()
        {
            return this.Items;
        }
        //********************************************************************
        public ExtractRoles()
        {
            this.Items = new List<UserRoleItem>();
        }
        //********************************************************************
        public async Task Write(IEnumerable<UserRoleItem> list, UserManager<AppUser> user_manager)
        {
            foreach (UserRoleItem item in list)
            {
                AppUser dbuser = await user_manager.FindByIdAsync(item.UserID);
                if (dbuser != null)
                {
                    switch (item.AssignRole)
                    {
                        case true:
                            if (await user_manager.IsInRoleAsync(dbuser, item.RoleName) == false)
                            {
                                await user_manager.AddToRoleAsync(dbuser, item.RoleName);
                            }
                            break;
                        case false:
                            if (await user_manager.IsInRoleAsync(dbuser, item.RoleName) == true)
                            {
                                await user_manager.RemoveFromRoleAsync(dbuser, item.RoleName);
                            }
                            break;
                    }
                }
            }
        }
        //********************************************************************
        public async Task Read(RoleManager<IdentityRole> manager, UserManager<AppUser> user_manager, string user_id)
        {
            AppUser key = await user_manager.FindByIdAsync(user_id);
            if (key != null)
            {
                List<IdentityRole> list_roles = manager.Roles.ToList();
                foreach (var role_item in list_roles)
                {
                    bool is_role = await user_manager.IsInRoleAsync(key, role_item.Name);


                    UserRoleItem element = new UserRoleItem()
                    {
                        RoleID = role_item.Id,
                        RoleName = role_item.Name,
                        AssignRole = is_role,
                        UserID = key.Id
                    };
                    this.Items.Add(element);
                }
            }
        }
        //********************************************************************

    }
}
