﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class LoginModel
    {
        [Required(ErrorMessage ="ErrorEmail")]
        [Display(Name ="DisplayEmail")]

        public string Email { get; set; }
        //---------------------------------------------------
        [Required(ErrorMessage ="ErrorPassword")]
        [Display(Name ="DisplayPassword")]
        public string Password { get; set; }
        //---------------------------------------------------
        public string ReturnUrl { get; set; }
        //---------------------------------------------------

    }
}
