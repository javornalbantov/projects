﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public interface ISessionReader
    {
        bool Empty();

        decimal Total();

        void Remove(int product_id);

        void Insert(int product_id, int quantity);
        void Update(int product_id, int quantity);

        IEnumerable<UserOrderedItem> Show();

        void ClearAll();
        Task Checkout();
    }
}
