﻿using Microsoft.AspNetCore.Razor.Language.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class AdminUsersPager
    {
        public readonly int page_size = 0;
        //*********************************************************************************************************
        public int page { get; set; }
        //*********************************************************************************************************
        public int totalpage { get; set; }

        //*********************************************************************************************************
        public string element_filter { get; set; }
        //*********************************************************************************************************
        private int PageCount(int list_count)
        {
            int result = (int)Math.Ceiling(list_count / (float)(this.page_size));
            return result;
        }
        //*********************************************************************************************************
        public void Details(int? id,int element_count,string filter)
        {
            this.element_filter = filter;
            this.page = id ?? 1;
            this.totalpage = this.PageCount(element_count);
        }
        //*********************************************************************************************************
        public AdminUsersPager()
        {
            this.page_size = 3;
        }
        //*********************************************************************************************************
        public static AdminUsersPager FromVB(dynamic element)
        {
            return element as AdminUsersPager;
        }
        //*********************************************************************************************************

    }

    

}
