﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public class OrderReader : IOrderReader
    {
        private const int page_size = 3;
        private SportStoreApplicationContext context_database = null;
        //*************************************************************************************************
        public OrderReader(SportStoreApplicationContext db)
        {
            this.context_database = db;
        }
        //*************************************************************************************************
        int IOrderReader.OrderPageCount()
        {
            int result = (int)Math.Ceiling(this.context_database.Orders.Count() / (float)page_size);
            return result;
        }
        //*************************************************************************************************
        IEnumerable<CurrentOrder> IOrderReader.List(int page)
        {
            IEnumerable<CurrentOrder> result = this.context_database.Orders.
                OrderByDescending(x => x.Orderdate).
                Skip((page - 1) * page_size).Take(page_size).
                Include(order => order.User).
                Include(order => order.OrderedProducts).
                ThenInclude(product => product.Product).
                Select
                (
                x =>
                new CurrentOrder()
                {

                    ID = x.Id,
                    OrderDate = x.Orderdate,
                    DeliveryAddress = x.User.Address,
                    DeliveryToDoor = x.User.DeliveryToHomeDoor ?? false,
                    Email = x.User.Email,
                    Details =  x.OrderedProducts.ToArray(),
                    TotalSum = (from product in x.OrderedProducts
                                select product.Product.Price).Sum()
                }
                );
            return result;
        }
        //*************************************************************************************************
    }
}
