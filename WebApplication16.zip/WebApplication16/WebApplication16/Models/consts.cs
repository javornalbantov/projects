﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class consts
    {


        public const string BgLev = "лв.";
        //най-много бройки от един елемент с едно поръчване от Home/Index
        public const int Home_Index = 20;

        //максимален брой за един елемент в кошницата
        //ManageShopMenu/Index
        public const int MAX_100 = 100;

        public const string BootstrapSingleTable = "col-sm-8 offset-sm-2";
        public const string BootstrapTableResults = "table table-striped table-bordered table-hover";
        public const string BootstrapEmptyList = "alert alert-success";
        public const string BootstrapAlertDanger = "alert alert-danger";
        public const string BootstrapButtonOK = "btn btn-primary";
        public const string BootstrapButtonCancel = "btn btn-link";
        public const string BootstrapButtonDanger = "btn btn-danger";

        public const string AdminLoginRole = "Admins";
        public const string UsersLoginRole = "Users";
    }
}
