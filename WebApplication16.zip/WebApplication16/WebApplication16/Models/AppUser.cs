﻿using Microsoft.AspNetCore.Identity;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class AppUser : IdentityUser
    {
        public int? PostalCode { get; set; }
        public string Address { get; set; }

        public int? Country { get; set; }

        public bool DeliveryToHomeDoor { get; set; }


        //***************************************************************************
        public LocalAppUser ToLocalAppUser(ICountryReader reader)
        {
            LocalAppUser result = new LocalAppUser()
            {

                ID = this.Id,
                PostalCode = this.PostalCode,
                Address = this.Address,
                Country = this.Country,
                DeliveryToHomeDoor = this.DeliveryToHomeDoor,
                UserName = this.UserName,
                Password = "",
                Email = this.Email,
                CountryOptions = reader.Get()
            };
            return result;
        }
        //***************************************************************************
    }
}
