﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public interface ISaveImage
    {
        string SuggestFileName(string input_file);

        string AbsoluteFileName(string directory,string input_file);

        void Delete(string filename);

        string ReadUploadedFileName(string input_file);

        string Upload(IFormFile uploader);



    }
}
