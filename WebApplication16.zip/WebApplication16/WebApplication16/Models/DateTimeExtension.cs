﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public static class DateTimeExtension
    {
        public static string LocalDate(this DateTime sender)
        {
            return sender.ToString("dd-MM-yyyy");
        }

        
    }
}
