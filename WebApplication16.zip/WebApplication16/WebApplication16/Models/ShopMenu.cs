﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public class ShopMenu:IShopMenu
    {
        private ICategoryManager category_manager = null;
        private IProductManager product_manager = null;

        private const int page_size = 3;
        //*****************************************************************************************
        int IShopMenu.TotalPages(int element_count)
        {
            return (int)Math.Ceiling(element_count / (float)ShopMenu.page_size);
        }

        //*****************************************************************************************
        public ShopMenu(
            ICategoryManager aCategoryManager,
            IProductManager aProductManager
            )
        {
            this.category_manager = aCategoryManager;
            this.product_manager = aProductManager;
        }
        

        //*****************************************************************************************
        IEnumerable<Category> IShopMenu.GetCategories()
        {
            return this.category_manager.List();
        }
        //*****************************************************************************************
        IEnumerable<ProductBridge> IShopMenu.GetProducts(int? categoryid, int? page_number,ref int unfiltered_count)
        {
            

            if (page_number.HasValue == false) page_number = 1;
            IEnumerable<ProductBridge> result = null;
            unfiltered_count = 0;

            if (categoryid.HasValue)
            {
                IEnumerable<ProductBridge> data = this.product_manager.List(Convert.ToInt32(categoryid));
                unfiltered_count = data.Count();

                result = data.Skip((Convert.ToInt32(page_number) - 1) * ShopMenu.page_size).Take(ShopMenu.page_size);
            }
            else
            {
                if (page_number.HasValue)
                {
                    IEnumerable<ProductBridge> data = this.product_manager.List();
                    unfiltered_count = data.Count();

                    result = data.Skip((Convert.ToInt32(page_number) - 1) * ShopMenu.page_size).Take(ShopMenu.page_size);
                }
                else
                {
                    result = this.product_manager.List();
                    unfiltered_count = result.Count();
                }
            }


            return result;
        }
        //*****************************************************************************************

        string IShopMenu.GetCategoryName(int category_id)
        {
            Category item = this.category_manager.FindById(category_id);
            return item.CategoryName;
        }

        //*****************************************************************************************
    }



   

}
