﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.CommonAttributes;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public class ProductBridge
    {

        //********************************************************************************************************
        public static ProductBridge FromProduct(Products sender)
        {
            ProductBridge result = new ProductBridge()
            {
                ID = sender.Id,
                CategoryID = sender.ProductCategory.First().CategoryId,
                Name = sender.Pname,
                Price = sender.Price,
                FileName = null,
                PreviewImageFile = sender.ProductImages.First().PreviewFile,
                Description = sender.Description
            };
            return result;
        }
        //********************************************************************************************************
        public static ProductBridge DefaultProduct()
        {

            ProductBridge result = new ProductBridge()
            {
                ID = null,
                Name = "",
                Description = "",
                Price = 0,
                FileName = null,
                PreviewImageFile = "",
                CategoryID = null
            };
            return result;
        }

        //********************************************************************************************************
        public int? ID { get; set; }
        //********************************************************************************************************
        public int? CategoryID { get; set; }
        //********************************************************************************************************
        [Display(Name="DisplayName")]
        [Required(AllowEmptyStrings =false,ErrorMessage ="ErrorName")]
        [MaxLength(50)]
        [CapitalizeFullName(ErrorMessage ="ErrorUpcase")]
        public string Name { get; set; }
        //********************************************************************************************************
        [Display(Name = "DisplayPrice")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "ErrorPrice")]
        public decimal? Price { get; set; }
        //********************************************************************************************************
        [Display(Name = "DisplayFileName")]
        public IFormFile FileName { get; set; }
        //********************************************************************************************************
        [Display(Name="DisplayPreviewImageFile")]
        public string PreviewImageFile { get; set; }
        //********************************************************************************************************
        [Display(Name = "DisplayDescription")]
        [Required(ErrorMessage ="ErrorDescription")]
        [MaxLength(4000)]
        public string Description { get; set; }
        
        //********************************************************************************************************
        public bool IsEdit()
        {
            return string.IsNullOrEmpty(this.PreviewImageFile) == false;
        }
        //********************************************************************************************************
    }
}
