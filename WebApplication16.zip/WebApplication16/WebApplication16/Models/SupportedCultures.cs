﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Globalization;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Razor;

namespace WebApplication16.Models
{
    public class SupportedCultures
    {
        private CultureInfo[] supportedCultures = null;
        //***********************************************************************************************
        public string DefaultCulture()
        {
            return "bg-BG";
        }
        //***********************************************************************************************
        public CultureInfo[] GetCultures()
        {
            return this.supportedCultures;
        }
        //***********************************************************************************************
        public SupportedCultures()
        {
            /*
             * ако не намери култура, която да идва от
             * ?culture=es-ES - primerno
             * cookie
             * Accept-Header : bg-bg;...
             * отива на DefaultCulture()
             */ 
            this.supportedCultures = new CultureInfo[]
            {
                new CultureInfo("en-US"),
                new CultureInfo("bg-BG"),
            };
            
        }
        //***********************************************************************************************
    }
}
