﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;


namespace WebApplication16.Models
{
    public class LocalAppUser
    {
        public const int min_range = 0;
        public const int max_range = 10000;

        
        //***************************************************************************
        public AppUser ToAppUser()
        {

            AppUser result = new AppUser()
            {
                PostalCode = this.PostalCode,
                Address = this.Address,
                Country = this.Country,
                DeliveryToHomeDoor = this.DeliveryToHomeDoor,
                UserName = this.UserName,
                Email = this.Email
            };
            return result;
            
        }
        //***************************************************************************
        public void Write(AppUser sender)
        {
            sender.PostalCode = this.PostalCode;
            sender.Address = this.Address;
            sender.Country = this.Country;
            sender.DeliveryToHomeDoor = this.DeliveryToHomeDoor;
            sender.UserName = this.UserName;
            sender.Email = this.Email;
        }
        //***************************************************************************
        public static LocalAppUser Empty(ICountryReader reader)
        {
            LocalAppUser result = new LocalAppUser()
            {
                ID = "no_id",
                CountryOptions = reader.Get(),
                Password = "",

                PostalCode = 0,
                Address = "",
                Country = null,
                DeliveryToHomeDoor = true,
                UserName = "",
                Email = ""
                
            };
            return result;

        }
        
        
        
        //***************************************************************************



        //potrebitelski elementi...
        public string ID { get; set; }
        
        
        //------------------------------------------------
        [Required(AllowEmptyStrings =false,ErrorMessage ="ErrorPostalCode")]
        [Display(Name = "DisplayPostalCode")]
        [Range(LocalAppUser.min_range,LocalAppUser.max_range,ErrorMessage ="RangePostalCode")]
        public int? PostalCode { get; set; }
        //------------------------------------------------
        [Display(Name = "DisplayAddress")]
        [MaxLength(255)]
        public string Address { get; set; }
        //------------------------------------------------
        [Required(ErrorMessage ="ErrorCountry")]
        [Display(Name = "DisplayCountry")]
        public int? Country { get; set; }
        //------------------------------------------------
        [Display(Name = "DisplayHomedoor")]
        public bool DeliveryToHomeDoor { get; set; }
        //***************************************************************************
        //ot IdentityUser
        [Required(AllowEmptyStrings =false,ErrorMessage ="ErrorUserName")]
        [Display(Name = "DisplayUserName")]
        [MaxLength(50)]
        public string UserName { get; set; }
        //------------------------------------------------
        [Required(AllowEmptyStrings =false,ErrorMessage ="ErrorPassword")]
        [Display(Name = "DisplayPassword")]
        [MaxLength(50)]
        public string Password { get; set; }
        //------------------------------------------------
        [Required(AllowEmptyStrings =false,ErrorMessage ="ErrorEmail")]
        [Display(Name = "DisplayEmail")]
        [MaxLength(50)]
        public string Email { get; set; }
        //***************************************************************************

        public IEnumerable<Country> CountryOptions { get; set; }
        
        
        //***************************************************************************
        public SelectList CountrySelectList(IEnumerable<Country> list)
        {
            
            SelectList result = new SelectList(list,
                nameof(DataTableModels.Country.Id),
                nameof(DataTableModels.Country.Name)
                );
            return result;
        }
        //****************************************************************************
    }
}
