﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;


namespace WebApplication16.Models
{
    public class CountryReader : ICountryReader
    {
        private SportStoreApplicationContext db = null;
        public CountryReader(SportStoreApplicationContext context)
        {
            this.db = context;
        }

        IEnumerable<Country> ICountryReader.Get()
        {
            Country[] result = 
            this.db.Country.OrderBy(x => x.Name).Select(x => x).ToArray();
                
            return result;
        }
    }
}
