﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public class CategoryElements
    {
        public int CategoryID { get; set; }
        public IEnumerable<ProductBridge> Elements { get; set; }

        public string CategoryName { get; set; }
        public bool Empty()
        {
            return this.Elements.Count() == 0;
        }


    }
}
