﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Server.IIS.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class UserRoleItem
    {
        public bool AssignRole { get; set; }

        public string RoleID { get; set; }
        public string RoleName { get; set; }
        public string UserID { get; set; }
    }

    
}
