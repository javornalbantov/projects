﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;


namespace WebApplication16.Models
{
    public interface ICountryReader
    {
        IEnumerable<Country> Get();
    }
}
