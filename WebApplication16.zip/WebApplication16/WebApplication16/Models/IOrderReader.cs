﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public interface IOrderReader
    {
        IEnumerable<CurrentOrder> List(int page);

        int OrderPageCount();
    }
}
