﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;

namespace WebApplication16.Models
{
    public static class StringExtensions
    {
        public static string allowed_chars(this string sender,string[] append)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string k in append)
            {
                sb.Append(k);
            }
            return sb.ToString();

        }

        public static bool FilterLike(this string sender, string search_filter)
        {
            

            bool result = false;
            if (string.IsNullOrEmpty(search_filter))
            {
                result = true;
            }
            else
            {
                search_filter = search_filter.Trim();
                result = sender.Contains(search_filter, StringComparison.OrdinalIgnoreCase);

            }

            return result;
        }
    }




}
