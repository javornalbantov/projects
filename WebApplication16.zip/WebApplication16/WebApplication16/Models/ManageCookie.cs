﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class ManageCookie
    {
        private IHttpContextAccessor http = null;
        //************************************************************************************
        public ManageCookie(IHttpContextAccessor cn)
        {
            this.http = cn;
        }
        public const string COOKIE_LANGUAGE = "UserCulture";
        //************************************************************************************
        public string CookieFromCulture(string culture)
        {
            string result = CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture));
            return result;
        }
        //************************************************************************************
        public void Set(string key, string value, int? expireTime)
        {
            CookieOptions option = new CookieOptions();
            option.IsEssential = true;//!!
            option.HttpOnly = false;
            option.Secure = true;
            if (expireTime.HasValue)
                option.Expires = DateTime.Now.AddMinutes(expireTime.Value);
            else
                option.Expires = DateTime.Now.AddMilliseconds(10);
            this.http.HttpContext.
            Response.Cookies.Append(key, value, option);
        }
        //************************************************************************************
        public void Remove(string key)
        {
            this.http.HttpContext.Response.Cookies.Delete(key);
        }
        //************************************************************************************
        public string Get(string key)
        {
            return this.http.HttpContext.Request.Cookies[key];
        }
        //************************************************************************************
    }
}
