﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;
using WebApplication16.ViewComponents;

namespace WebApplication16.Models
{
    [Serializable]
    public class ListOrderedItems: IListOrderedItems
    {
        private List<UserOrderedItem> data = null;
        
        //*****************************************************************************************************************
        public ListOrderedItems()
        {
            this.data = new List<UserOrderedItem>();
        }
        
        //*****************************************************************************************************************
        bool IListOrderedItems.Empty()
        {
            return this.data.Count() == 0;
        }
        //*****************************************************************************************************************
        decimal IListOrderedItems.Total()
        {
            decimal result =
                this.data.Sum(x => x.IntermdSum());
            return result;
        }

        //*****************************************************************************************************************
        void IListOrderedItems.Remove(int product_id)
        {
            int index = this.data.FindIndex
                (
                delegate (UserOrderedItem item)
                {
                    return item.ProductID == product_id;
                }
                );
            if (index != -1)
            {
                this.data.RemoveAt(index);
            }

        }
        
        //*****************************************************************************************************************
        void IListOrderedItems.Insert(int product_id, decimal product_price, string product_name, int quantity,string preview_file)
        {
            //този метод се изпълнява от Home/Index => бутон Поръчай
            UserOrderedItem order = null;
            
            bool in_card = this.data.Any(x => x.ProductID == product_id);
            switch (in_card)
            {
                case true:
                    order = this.data.Where(x => x.ProductID == product_id).First();
                    if (order.Quantity + Math.Abs(quantity) > consts.MAX_100)
                    {
                        order.Quantity = consts.MAX_100;
                    }
                    else
                    {
                        order.Quantity += Math.Abs(quantity);
                    }
                    break;
                case false:

                    order = new UserOrderedItem()
                    {
                        Quantity = Math.Min(Math.Abs(quantity), consts.MAX_100),
                        ProductID = product_id,
                        ProductPrice = product_price,
                        ProductName = product_name,
                        PreviewFilename = preview_file
                    };
                    this.data.Add(order);
                    break;
            }


        }
        //*****************************************************************************************************************
        void IListOrderedItems.Update(int product_id, int quantity)
        {
            //изпълнява се като корекция на поръчката
            bool in_card = this.data.Any(x => x.ProductID == product_id);
            if (in_card)
            {
                var order = this.data.Where(x => x.ProductID == product_id).First();
                if (quantity != 0)
                {
                    order.Quantity = Math.Min(Math.Abs(quantity), consts.MAX_100);
                }
                else
                {
                    this.data.Remove(order);
                }
            }

        }
        //*****************************************************************************************************************
        void IListOrderedItems.ClearAll()
        {
            this.data.Clear();
        }
        //*****************************************************************************************************************
        IEnumerable<UserOrderedItem> IListOrderedItems.Show()
        {
            return this.data;
        }
        //*****************************************************************************************************************

    }
}
