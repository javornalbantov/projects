﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class ShopItemsPager
    {
        
        public int? CategoryID { get; set; }
        //*********************************************************************************************************

        public int? PageID { get; set; }

        //*********************************************************************************************************
        public static ShopItemsPager FromVB(dynamic sender)
        {
            return sender as ShopItemsPager;
        }
        //*********************************************************************************************************

       
    }
}
