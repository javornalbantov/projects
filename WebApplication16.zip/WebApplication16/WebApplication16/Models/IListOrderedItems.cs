﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public interface IListOrderedItems
    {
        void Insert(int product_id, decimal product_price, string product_name, int quantity, string preview_file);

        void Remove(int product_id);

        decimal Total();

        
        bool Empty();

        void ClearAll();

        void Update(int product_id, int quantity);

        IEnumerable<UserOrderedItem> Show();


    }
}
