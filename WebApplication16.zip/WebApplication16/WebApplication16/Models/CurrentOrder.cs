﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public class CurrentOrder
    {
        public int ID { get; set; }//номер на поръчката

        public string Email { get; set; }

        public DateTime OrderDate { get; set; }

        public string DeliveryAddress { get; set; }

        public bool DeliveryToDoor { get; set; }

        public IEnumerable<OrderedProducts> Details { get; set; }

        public decimal TotalSum { get; set; }

        public string PrintTrue(bool key)
        {
            if (key)
            {
                return "X";
            }
            else
            {
                return "";
            }
        }
    }
   
}
