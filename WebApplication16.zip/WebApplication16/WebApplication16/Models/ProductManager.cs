﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;
using Microsoft.AspNetCore.Razor.Language;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Razor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public class ProductManager : IProductManager
    {
        private SportStoreApplicationContext db = null;
        private ISaveImage save_manager = null;

        //********************************************************************************************************
        public ProductManager(SportStoreApplicationContext context,ISaveImage aSaveManager)
        {
            this.db = context;
            this.save_manager = aSaveManager;
        }
        //********************************************************************************************************
        string IProductManager.GetcategoryName(int category_id)
        {
            string result = this.db.Category.Where(x => x.Id == category_id).First().CategoryName;
            return result;
        }
        
        //********************************************************************************************************
        ProductBridge IProductManager.Details(int product_id)
        {
            ProductBridge result = null;
            bool ok = this.db.Products.Any(x => x.Id == product_id);
            if (ok)
            {
                /*
                 * замислено е да се сложат няколко снимки...
                 * засега вземаме само First()
                 * иначе трябва да върне колекция
                 */
                result = (this as IProductManager).List()
                    .Where(x => x.ID == product_id).First();
                   
            }
            else
            {
                result = null;
            }
            return result;
        }
        //********************************************************************************************************
        bool IProductManager.Edit(ProductBridge sender)
        {
            bool result = false;
            try
            {
                //promenqme snimkata...
                string guid_name = "";
                if (sender.FileName != null)
                {
                    guid_name = this.save_manager.Upload(sender.FileName);
                }
                bool ok = this.db.Products.Any(x => x.Id == sender.ID);
                if (ok)
                {
                    

                    Products element = this.db.Products.
                        Include(product=>product.ProductImages).
                        Where(product => product.Id == sender.ID).
                        First();
                    element.Pname = sender.Name.Trim();
                    element.Description = sender.Description.Trim();
                    element.Price = Convert.ToDecimal(sender.Price);

                    if (string.IsNullOrEmpty(guid_name) == false)
                    {
                        element.ProductImages.
                            First().
                            PreviewFile = this.save_manager.ReadUploadedFileName(guid_name);
                    }
                    this.db.SaveChanges();
                    result = true;
                }
            }
            catch (Exception msg)
            {
                result = false;
            }
            return result;
        }
        //********************************************************************************************************
        bool IProductManager.Insert(ProductBridge sender)
        {
            bool result = false;
            try
            {
                string guid_name = this.save_manager.Upload(sender.FileName);
                

                Products item_product = new Products()
                {
                    Pname = sender.Name.Trim(),
                    Description = sender.Description.Trim(),
                    Price = Convert.ToDecimal(sender.Price)
                    ,
                    ProductImages = new List<ProductImages>()
                    {
                        new ProductImages()
                        {
                            PreviewFile = this.save_manager.ReadUploadedFileName(guid_name)
                        }
                    }
                    ,
                    ProductCategory = new List<ProductCategory>()
                    {
                        new ProductCategory()
                        {
                            CategoryId = sender.CategoryID
                        }
                    }
                };
                this.db.Products.Add(item_product);
                //---------------------------------
                this.db.SaveChanges();
                //---------------------------------

                result = true;
            }
            catch (Exception msg)
            {
                //transaction.Rollback();
                result = true;
            }
            return result;

        }
        //********************************************************************************************************
        IEnumerable<ProductBridge> IProductManager.List(int category_id)
        {

            IEnumerable<ProductBridge> result = (this as IProductManager).
                List().
                Where(x => x.CategoryID == category_id);
            return result;

        }
        //********************************************************************************************************
        IEnumerable<ProductBridge> IProductManager.List()
        {

            IEnumerable<Products> list =
            this.db.Products.Include(x => x.ProductCategory).Include(x => x.ProductImages).ToList();


            IEnumerable<ProductBridge> result = from x in list
                                                select ProductBridge.FromProduct(x);
                                                
            return result;

        }
        //********************************************************************************************************
        void IProductManager.Delete(int id)
        {
            bool ok = this.db.Products.Any(x => x.Id == id);
            if (ok)
            {
                
                Products list =
                    this.db.Products.Include(x => x.ProductCategory).Include(x => x.ProductImages).Where(x => x.Id == id).First();
                string[] fname = list.ProductImages.Select(x => x.PreviewFile).ToArray();

                this.db.Products.Remove(list);
                this.db.SaveChanges();

                foreach(string k in fname)
                {
                    this.save_manager.Delete(k);
                }
            }
        }
        //********************************************************************************************************
    }
}
