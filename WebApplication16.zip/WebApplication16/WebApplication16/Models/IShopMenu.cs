﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public interface IShopMenu
    {
        //всички категории
        IEnumerable<Category> GetCategories();
        //-----------------------------------------------------------------------
        //странициране по категория и номер на страница
        IEnumerable<ProductBridge> GetProducts(int? categoryid, int? page_number, ref int unfiltered_count);
        //-----------------------------------------------------------------------
        string GetCategoryName(int category_id);
        //-----------------------------------------------------------------------
        int TotalPages(int element_count);
        //-----------------------------------------------------------------------

    }
}
