﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public interface ICategoryManager
    {
        IEnumerable<Category> List();
        //********************************************************************************************************
        void DeleteCategory(int id);
        //********************************************************************************************************
        void AddCategory(Category sender);
        //********************************************************************************************************

        void EditCategory(Category sender);
        //********************************************************************************************************

        Category FindById(int id);
        //********************************************************************************************************

        Category Empty();
        //********************************************************************************************************

    }

    
}
