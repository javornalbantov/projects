﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.Models
{
    public class TranslateUIModel
    {
        public string ReturnUrl { get; set; }
        public CultureInfo[] Languages { get; set; }

        public string DisplayFirst2Letters(CultureInfo element)
        {
            string result = element.DisplayName;

            if (element.DisplayName.IndexOf('(') > -1)
            {
                result = element.DisplayName.
                    Substring(0, element.DisplayName.IndexOf('(')).
                    Trim();
            }
            
            return result;

        }

    }
}
