﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Razor.Language.Extensions;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Localization;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Razor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.DataTableModels;

namespace WebApplication16.Models
{
    public interface IProductManager
    {
        string GetcategoryName(int category_id);
        //********************************************************************************************************
        IEnumerable<ProductBridge> List(int category_id);
        //********************************************************************************************************
        IEnumerable<ProductBridge> List();
        //********************************************************************************************************
        void Delete(int id);
        //********************************************************************************************************

        bool Insert(ProductBridge sender);
        //********************************************************************************************************

        bool Edit(ProductBridge sender);
        //********************************************************************************************************
        ProductBridge Details(int product_id);
        
        //********************************************************************************************************
    }




}
