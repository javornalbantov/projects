﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication16.DataTableModels
{
    [Table("COUNTRY")]
    public partial class Country
    {
        public Country()
        {
            AspNetUsers = new HashSet<AspNetUsers>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("NAME")]
        [StringLength(100)]
        public string Name { get; set; }

        [InverseProperty("CountryNavigation")]
        public virtual ICollection<AspNetUsers> AspNetUsers { get; set; }

        
    }
}
