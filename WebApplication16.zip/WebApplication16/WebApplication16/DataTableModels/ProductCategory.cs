﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication16.DataTableModels
{
    [Table("PRODUCT_CATEGORY")]
    public partial class ProductCategory
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("PRODUCT_ID")]
        public int? ProductId { get; set; }
        [Column("CATEGORY_ID")]
        public int? CategoryId { get; set; }

        [ForeignKey(nameof(CategoryId))]
        [InverseProperty("ProductCategory")]
        public virtual Category Category { get; set; }
        [ForeignKey(nameof(ProductId))]
        [InverseProperty(nameof(Products.ProductCategory))]
        public virtual Products Product { get; set; }

        
    }
}
