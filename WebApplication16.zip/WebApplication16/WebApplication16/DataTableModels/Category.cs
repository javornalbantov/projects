﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WebApplication16.CommonAttributes;

namespace WebApplication16.DataTableModels
{
    [Table("CATEGORY")]
    public partial class Category
    {
        public Category()
        {
            ProductCategory = new HashSet<ProductCategory>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "ErrorCategoryName")]
        [CapitalizeFullName(ErrorMessage = "UpcaseCategory")]
        [Display(Name = "DisplayCategory")]
        [Column("CATEGORY_NAME")]
        [StringLength(100)]
        public string CategoryName { get; set; }

        [InverseProperty("Category")]
        public virtual ICollection<ProductCategory> ProductCategory { get; set; }

        
    }
}
