﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication16.DataTableModels
{
    [Table("ORDERS")]
    public partial class Orders
    {
        public Orders()
        {
            OrderedProducts = new HashSet<OrderedProducts>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("USERID")]
        [StringLength(450)]
        public string Userid { get; set; }
        [Column("ORDERDATE", TypeName = "date")]
        public DateTime Orderdate { get; set; }

        [ForeignKey(nameof(Userid))]
        [InverseProperty(nameof(AspNetUsers.Orders))]
        public virtual AspNetUsers User { get; set; }
        [InverseProperty("Order")]
        public virtual ICollection<OrderedProducts> OrderedProducts { get; set; }
    }
}
