﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication16.DataTableModels
{
    [Table("PRODUCT_IMAGES")]
    public partial class ProductImages
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("PRODUCT_ID")]
        public int? ProductId { get; set; }
        [Column("PREVIEW_FILE")]
        [StringLength(100)]
        public string PreviewFile { get; set; }

        [ForeignKey(nameof(ProductId))]
        [InverseProperty(nameof(Products.ProductImages))]
        public virtual Products Product { get; set; }
    }
}
