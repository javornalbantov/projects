﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication16.DataTableModels
{
    [Table("PRODUCTS")]
    public partial class Products
    {
        public Products()
        {
            OrderedProducts = new HashSet<OrderedProducts>();
            ProductCategory = new HashSet<ProductCategory>();
            ProductImages = new HashSet<ProductImages>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("PNAME")]
        [StringLength(200)]
        public string Pname { get; set; }
        [Column("PRICE", TypeName = "decimal(10, 2)")]
        public decimal Price { get; set; }
        [Required]
        [Column("DESCRIPTION")]
        [StringLength(4000)]
        public string Description { get; set; }

        [InverseProperty("Product")]
        public virtual ICollection<OrderedProducts> OrderedProducts { get; set; }
        [InverseProperty("Product")]
        public virtual ICollection<ProductCategory> ProductCategory { get; set; }
        [InverseProperty("Product")]
        public virtual ICollection<ProductImages> ProductImages { get; set; }
    }
}
