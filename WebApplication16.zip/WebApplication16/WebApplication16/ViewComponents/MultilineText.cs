﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication16.ViewComponents
{
    public class MultilineText:ViewComponent
    {
        private string split_div(string caption)
        {
            string[] list = caption.Split(Environment.NewLine);
            StringBuilder sb = new StringBuilder();
            bool read_more = false;
            for (int i = 0; i < list.Length; i++)
            {
                if (i == 10 && read_more == false)
                {
                    read_more = true;
                    sb.Append("<span class='readmore'>");
                }
                sb.Append(string.Format("{0}<br/>", list[i]));
                
            }
            if(read_more)
            {
                sb.Append("</span><button class='btn btn-link rmbutton' onclick='readmore(this)'>read-more-button</button>");// za class='readmore'
            }



            return sb.ToString();
        }


        public IViewComponentResult Invoke(string caption)
        {

            return 
                new HtmlContentViewComponentResult(new HtmlString(this.split_div(caption)));
        }
    }
}
