﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.Models;

namespace WebApplication16.ViewComponents
{
    public class TranslateUI:ViewComponent
    {
        private SupportedCultures elements = null;
        private IHttpContextAccessor context = null;
        
        public TranslateUI(
            SupportedCultures aSupporedCulture, 
            IHttpContextAccessor http
            
            )
        {
            
            this.elements = aSupporedCulture;
            this.context = http;
        }

        public IViewComponentResult Invoke()
        {
            string current_controller = this.context.HttpContext.Request.RouteValues["controller"].ToString();
            
            TranslateUIModel data = new TranslateUIModel()
            {
                ReturnUrl = Url.Action("Index",current_controller),
                Languages = this.elements.GetCultures()
            };
            return View(data);
        }
    }
}
