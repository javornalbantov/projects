﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.Models;

namespace WebApplication16.ViewComponents
{
    public class AddToCard:ViewComponent
    {
        private IHttpContextAccessor http;
        private UserManager<AppUser> user_manager = null;
        public AddToCard(IHttpContextAccessor context,UserManager<AppUser> aManager)
        {
            this.http = context;
            this.user_manager = aManager;


            //this.http.HttpContext.Request.GetEncodedPathAndQuery();
            

        }
        public async Task<IViewComponentResult> InvokeAsync(ProductBridge sender)
        {
            if (this.http.HttpContext.User.Identity.IsAuthenticated)
            {

                AppUser dbuser = await this.user_manager.GetUserAsync(this.http.HttpContext.User);
                bool is_user = await this.user_manager.IsInRoleAsync(dbuser, consts.UsersLoginRole);
                if (is_user)
                {
                    ViewBag.returnUrl = this.http.HttpContext.Request.GetEncodedPathAndQuery();
                    return View(sender);
                }
                else
                {
                    return Content(string.Empty);
                }
            }
            else
            {
                return Content(string.Empty);
            }
        }


    }
}
