﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication16.Models;

namespace WebApplication16.ViewComponents
{
    public class TestRegisteredUser:ViewComponent
    {
        private IHttpContextAccessor http = null;
        private UserManager<AppUser> manager = null;
        private ISessionReader order = null;
        //***************************************************************************************************************
        public TestRegisteredUser(IHttpContextAccessor cn,UserManager<AppUser> mn, ISessionReader aOrder)
        {
            this.http = cn;
            this.manager = mn;
            this.order = aOrder;
        }
        //***************************************************************************************************************
        public async Task<IViewComponentResult> InvokeAsync()
        {
            UserDescription data = new UserDescription()
            {
                UserName = "",
                UserType = LoginType.None,
                UserID = "",
                OrderItems = 0
            };
            if (this.http.HttpContext.User.Identity.IsAuthenticated)
            {
                
                AppUser dbuser =await this.manager.GetUserAsync(this.http.HttpContext.User);
                bool is_admin = await this.manager.IsInRoleAsync(dbuser, consts.AdminLoginRole);
                if (is_admin)
                {
                    data = new UserDescription()
                    {
                        UserName = dbuser.UserName,
                        UserType = LoginType.Admin,
                        UserID = dbuser.Id,
                        OrderItems = this.order.Show().Count()
                    };
                }
                else
                {
                    data = new UserDescription()
                    {
                        UserName = dbuser.UserName,
                        UserType = LoginType.CasualUser,
                        UserID = dbuser.Id,
                        OrderItems = this.order.Show().Count()
                    };
                }
            }

            return View(data);
        }
        //***************************************************************************************************************
    }
}
