using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using WebApplication16.Models;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;
using WebApplication16.DataTableModels;
using WebApplication16.CommonAttributes;
using Microsoft.AspNetCore.Mvc.DataAnnotations;
using System.Text;

namespace WebApplication16
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        //***************************************************************************************************************************************
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        
        //***************************************************************************************************************************************
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddHttpContextAccessor();
            services.AddTransient<SupportedCultures>();
            services.AddTransient<IValidationAttributeAdapterProvider, CustomValidationAttributeAdapterProvider>();

            services.AddTransient<ISaveImage, SaveImage>();
            
            
            
            services.AddTransient<ICountryReader, CountryReader>();
            services.AddTransient<ICategoryManager, CategoryManager>();
            services.AddTransient<IProductManager, ProductManager >();
            services.AddTransient<IShopMenu, ShopMenu>();
            services.AddTransient<ISessionReader,SessionReader>();
            services.AddTransient<IOrderReader, OrderReader>();

            services.AddLocalization
                (
                    options =>
                    {
                        options.ResourcesPath = "Resources";
                    }
                );
            
            services.AddDbContext<SportStoreApplicationContext>
                   (options =>
                   options.UseSqlServer
                       (
                       Configuration.
                       GetSection("Data").
                       GetSection("SportStoreIdentity").
                       GetValue<string>("ConnectionString")
                       )
                   );
                   
            //----------------------------------------


            services.AddDbContext<AppIdentityDbContext>(options =>
             options.UseSqlServer
             (
                Configuration.
                    GetSection("Data").
                    GetSection("SportStoreIdentity").
                    GetValue<string>("ConnectionString")));
            services.AddIdentity<AppUser, IdentityRole>
                (
                options=>
                {
                    options.Password.RequireUppercase = false;
                    options.Password.RequireNonAlphanumeric = false;
                    options.User.RequireUniqueEmail = true;
                    string cyrillic = "������������������������������";
                    options.User.AllowedUserNameCharacters =

                    options.User.AllowedUserNameCharacters.allowed_chars
                    (
                        new string[]
                        {
                            cyrillic,
                            cyrillic.ToUpper(),
                            " ",
                            options.User.AllowedUserNameCharacters
                        }
                    );
                    

                }
                )
            .AddEntityFrameworkStores<AppIdentityDbContext>()
            .AddDefaultTokenProviders();

            services.AddMemoryCache();
            services.AddSession();
            //----------------------------------------
            services.
                AddControllersWithViews().
                AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix).
                AddDataAnnotationsLocalization();

            
        }
        //***************************************************************************************************************************************
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();//v tozi red...
            app.UseAuthorization();//.. v tozi red
            //-----------------------------------------
            SupportedCultures supported_cultures = new SupportedCultures();
            RequestLocalizationOptions localizationOptions = new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture(supported_cultures.DefaultCulture()),
                SupportedCultures = supported_cultures.GetCultures(),
                SupportedUICultures = supported_cultures.GetCultures()
            };
            localizationOptions.RequestCultureProviders
            .OfType<CookieRequestCultureProvider>()
            .First().CookieName = ManageCookie.COOKIE_LANGUAGE;
            app.UseRequestLocalization(localizationOptions);

            app.UseSession();
            //-----------------------------------------
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");

                
            });
        }
        //***************************************************************************************************************************************
    }
}
