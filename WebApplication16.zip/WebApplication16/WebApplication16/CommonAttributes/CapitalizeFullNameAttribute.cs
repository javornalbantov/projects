﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.CommonAttributes
{
    public class CapitalizeFullNameAttribute : ValidationAttribute
    {
        //първите букви в името трябва да са главни
        public override bool IsValid(object obj)
        {
            bool result = false;
            string item = obj as string;

            if (string.IsNullOrEmpty(item) == false)
            {
                item = item.Trim();
                if (item.Length > 0)
                {
                    if (Char.IsUpper(item[0]))
                    {
                        result = true;
                    }
                }
            }

            return result;
        }
    }

}
