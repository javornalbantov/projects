﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    
    public class ProductUserController : Controller
    {
        
        private ICountryReader country_reader = null;
        private RoleManager<IdentityRole> role_manager = null;
        private UserManager<AppUser> manager = null;
        private IPasswordHasher<AppUser> pass_maker = null;
        private IUserValidator<AppUser> user_validator = null;
        private IPasswordValidator<AppUser> pass_validator = null;
        //*******************************************************************************************
        public ProductUserController(
            ICountryReader reader,
            RoleManager<IdentityRole> aRoleManager,
            UserManager<AppUser> aManager,
            IUserValidator<AppUser> aUserValidator,
            IPasswordValidator<AppUser> aPassValidator,
            IPasswordHasher<AppUser> aPassHasher 
            )
        {
            this.country_reader = reader;
            this.manager = aManager;
            this.role_manager = aRoleManager;
            this.pass_maker = aPassHasher;
            this.user_validator = aUserValidator;
            this.pass_validator = aPassValidator;
        }
        //*******************************************************************************************
        public IActionResult Index()
        {

            return View(LocalAppUser.Empty(this.country_reader));
        }
        //*******************************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(LocalAppUser sender)
        {
            if (ModelState.IsValid)
            {
                AppUser db_user = sender.ToAppUser();
                IdentityResult db_result =
                await this.manager.CreateAsync(db_user, sender.Password);

                if (db_result.Succeeded)
                {
                    //прибавя се като обикновен потребител...
                    IdentityRole users_role = await this.role_manager.FindByNameAsync(consts.UsersLoginRole);
                    if (users_role != null)
                    {
                        await this.manager.AddToRoleAsync(db_user, users_role.Name);
                    }
                    return RedirectToAction("Login", "Account",new { returnUrl="/"});
                }
                else
                {
                    ModelState.AddMultipleErrors(db_result.Errors);

                    sender.CountryOptions = this.country_reader.Get();
                    return View("Index", sender);
                }
            }
            else
            {
                sender.CountryOptions = this.country_reader.Get();
                return View("Index", sender);
            }
        }
        //*******************************************************************************************
        [Authorize(Roles =consts.UsersLoginRole)]
        public async Task<IActionResult> Details(string id)
        {
            AppUser key = await this.manager.FindByIdAsync(id);
            if (key != null)
            {

                return View(key.ToLocalAppUser(this.country_reader));
            }
            else
            {
                return NotFound();
            }
        }
        //*******************************************************************************************
        [Authorize(Roles = consts.UsersLoginRole)]
        [HttpPost,ValidateAntiForgeryToken]
        public async Task<IActionResult> Details(LocalAppUser sender)
        {
            if (ModelState.IsValid)
            {

                AppUser create_user = await this.manager.FindByIdAsync(sender.ID);
                if (create_user != null)
                {
                    sender.Write(create_user);
                    IdentityResult result_password = await this.pass_validator.ValidateAsync(this.manager, create_user, sender.Password);
                    IdentityResult result_username = await this.user_validator.ValidateAsync(this.manager, create_user);
                    if (result_username.Succeeded == false)
                    {
                        ModelState.AddMultipleErrors(result_username.Errors);
                    }
                    if (result_password.Succeeded == false)
                    {
                        ModelState.AddMultipleErrors(result_password.Errors);
                    }
                    if (ModelState.ErrorCount == 0)
                    {
                        create_user.PasswordHash = this.pass_maker.HashPassword(create_user, sender.Password);
                        await this.manager.UpdateAsync(create_user);
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        sender.CountryOptions = this.country_reader.Get();
                        return View(sender);
                    }
                }
                else
                    return BadRequest();

            }
            else
            {
                sender.CountryOptions = this.country_reader.Get();
                return View(sender);
            }
        }
        
        
        //*******************************************************************************************
    }
}