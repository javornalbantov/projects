﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IIS.Core;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    public class HomeController : Controller
    {
       
        private IShopMenu shop_menu = null;
        //*************************************************************************************************************************************
        public HomeController
            (
            IShopMenu aShopMenu
            )
        {
            this.shop_menu = aShopMenu;
            
        }
        //*************************************************************************************************************************************
        public IActionResult Index(int? category,int? page_id)
        {
            

            ViewBag.filter = new ShopItemsPager()
            {
                PageID = page_id ?? 1,
                CategoryID = category
            };

            
            return View(this.shop_menu);
        }
        //*************************************************************************************************************************************
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        //*************************************************************************************************************************************
    }
}
