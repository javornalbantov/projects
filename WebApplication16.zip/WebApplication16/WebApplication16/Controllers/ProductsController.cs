﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.Language.Extensions;
using Microsoft.Extensions.Localization;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    [Authorize(Roles = consts.AdminLoginRole)]
    public class ProductsController : Controller
    {
        private IProductManager manager = null;
        private IStringLocalizer<ProductsController> captions = null;
        //************************************************************************************
        public ProductsController(IProductManager mn,IStringLocalizer<ProductsController> aCaptions)
        {
            this.manager = mn;
            this.captions = aCaptions;
        }
        //************************************************************************************
        public IActionResult Index(int? id)
        {
            if (id.HasValue)
            {
                CategoryElements data = new CategoryElements()
                {
                    CategoryID = Convert.ToInt32(id),
                    CategoryName = this.manager.GetcategoryName(Convert.ToInt32(id)),
                    Elements = this.manager.List(Convert.ToInt32(id))
                };
                return View(data);
            }
            else
            {
                return RedirectToAction("Index", "Category");
            }
        }
        //************************************************************************************
        public IActionResult Create(int? id)
        {
            if (id.HasValue)
            {
                ProductBridge item = ProductBridge.DefaultProduct();
                
                item.CategoryID = id;
                return View(item);
            }
            else
            {
                return RedirectToAction("Index", "Category");
            }

        }
        //************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Create(ProductBridge sender)
        {

            if (sender.FileName == null)
            {
                ModelState.AddModelError(nameof(sender.FileName), this.captions.GetString("ErrorFileName"));
            }

            if (ModelState.IsValid)
            {
                this.manager.Insert(sender);
                return RedirectToAction("Index", "Products", new { id = sender.CategoryID });
            }
            else
            {
                return View("Create", sender);
                     
            }
        }

        //************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Delete(int id,int categoryid)
        {
            this.manager.Delete(id);
            return RedirectToAction("Index", "Products",new {id=categoryid });
        }
        //************************************************************************************
        public IActionResult Details(int id)
        {
            ProductBridge element = this.manager.Details(id);
            if (element != null)
            {
                
                return View(element);
            }
            else
            {
                return BadRequest();
            }
        }
        //************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Details(ProductBridge sender)
        {
            var element = this.manager.Details(Convert.ToInt32(sender.ID));
            if (element != null)
            {
                if (ModelState.IsValid)
                {
                    this.manager.Edit(sender);
                    return RedirectToAction("Index", "Products", new { id = sender.CategoryID });
                }
                else
                {
                    return View(sender);
                }
            }
            else
            {
                return RedirectToAction("Index", "Products");
            }
        }
        //************************************************************************************

    }
}