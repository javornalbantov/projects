﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    [Authorize(Roles = consts.AdminLoginRole)]
    public class AdminController : Controller
    {
        private IOrderReader order_reader = null;

        public AdminController(IOrderReader aOrderReader)
        {
            this.order_reader = aOrderReader;
        }

        public IActionResult Index(int? id)
        {
            ViewBag.filter = new ShopItemsPager()
            {
                PageID = id ?? 1
            };
            return View(this.order_reader);
        }
    }
}