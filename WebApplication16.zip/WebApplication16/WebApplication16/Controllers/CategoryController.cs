﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication16.Models;
using WebApplication16.DataTableModels;

namespace WebApplication16.Controllers
{
    [Authorize(Roles = consts.AdminLoginRole)]
    public class CategoryController : Controller
    {
        private ICategoryManager manager = null;
        //******************************************************************************
        public CategoryController(ICategoryManager mn)
        {
            this.manager = mn;
        }
        //******************************************************************************
        public IActionResult Index()
        {
            return View(this.manager.List());
        }
        //******************************************************************************
        public IActionResult Create()
        {
            return View(this.manager.Empty());
        }
        //******************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Category sender)
        {
            if (ModelState.IsValid)
            {
                this.manager.AddCategory(sender);
                return RedirectToAction("Index", "Category");
            }
            else
            {
                return View("Create", sender);

            }
        }
        //******************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            this.manager.DeleteCategory(id);
            return RedirectToAction("Index", "Category");
        }
        //******************************************************************************
        public IActionResult Edit(int id)
        {
            Category result = this.manager.FindById(id);
            if (result == null)
            {
                return BadRequest();
            }else
            {
                return View(result);
            }
        }
        //******************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Edit(Category sender)
        {
            if (ModelState.IsValid)
            {
                this.manager.EditCategory(sender);
                return RedirectToAction("Index", "Category");
            }else
            {
                return View("Edit", sender);
            }
        }
        //******************************************************************************



    }
}