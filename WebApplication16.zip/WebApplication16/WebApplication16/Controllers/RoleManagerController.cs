﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    [Authorize(Roles = consts.AdminLoginRole)]
    public class RoleManagerController : Controller
    {
        private RoleManager<IdentityRole> manager = null;
        //********************************************************************************************************************
        public RoleManagerController(RoleManager<IdentityRole> aManager)
        {
            this.manager = aManager;
        }
        //********************************************************************************************************************
        public IActionResult Index()
        {
            return View(this.manager.Roles.OrderBy(x=>x.Name));
        }
        //********************************************************************************************************************
        public IActionResult Create()
        {
            return View(IdentityFrameworkRole.Default());
        }

        //********************************************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(IdentityFrameworkRole sender)
        {
            if (ModelState.IsValid)
            {
                IdentityResult success = 
                await this.manager.CreateAsync(new IdentityRole(sender.RoleName));
                if (success.Succeeded)
                {
                    return RedirectToAction("Index", "RoleManager");
                }
                else
                {
                    ModelState.AddMultipleErrors(success.Errors);
                    return View("Create", sender);
                }
            }
            else
            {
                return View("Create", sender);
            }
        }
        //********************************************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(string id)
        {
            var element  = await this.manager.FindByIdAsync(id);
            if(element!=null)
            {
                await this.manager.DeleteAsync(element);
            }
            return RedirectToAction("Index", "RoleManager");
        }
        //********************************************************************************************************************

    }
}