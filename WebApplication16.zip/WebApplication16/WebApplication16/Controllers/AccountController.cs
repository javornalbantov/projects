﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IIS.Core;
using Microsoft.Extensions.Localization;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private SignInManager<AppUser> signin = null;
        private UserManager<AppUser> users = null;
        private IStringLocalizer<AccountController> captions = null;
        
        //**************************************************************************
        public AccountController(
            SignInManager<AppUser> manager,
            UserManager<AppUser> mn,
            IStringLocalizer<AccountController> aCaptions)
        {
            this.signin = manager;
            this.users = mn;
            this.captions = aCaptions;
        }
        //**************************************************************************
        public IActionResult Index()
        {
            return RedirectToAction("Login", new { returnUrl = "/" });
        }
        //**************************************************************************
        [AllowAnonymous]
        public IActionResult Login(string returnUrl)
        {
            
            LoginModel login = new LoginModel()
            {
                Email = "",
                Password = "",
                ReturnUrl = returnUrl
            };
            return View(login);
        }
        //**************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        [AllowAnonymous]
        public async  Task<IActionResult> Login(LoginModel sender)
        {
            if (ModelState.IsValid)
            {
                AppUser dbuser = await this.users.FindByEmailAsync(sender.Email);
                if (dbuser != null)
                {
                    await this.signin.SignOutAsync();
                    var success = await this.signin.PasswordSignInAsync(dbuser, sender.Password, false, false);
                    if (success.Succeeded)
                    {
                        bool is_admin =
                            await this.users.IsInRoleAsync(dbuser, consts.AdminLoginRole);
                        if (is_admin)
                        {
                            return RedirectToAction("Index", "Admin");
                        }

                        else
                        {
                            return Redirect(sender.ReturnUrl);
                        }
                    } 
                    else
                    {
                        
                        ModelState.AddModelError(nameof(LoginModel.Email), this.captions.GetString("String1"));
                        return View("Login", sender);
                    }
                }
                else
                {
                    ModelState.AddModelError(nameof(LoginModel.Email), this.captions.GetString("String1"));
                    return View("Login", sender);
                }
            }
            else
            {
                return View("Login", sender);
            }
        }
        //**************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            if (this.signin != null)
            {
                this.signin.SignOutAsync();
            }
            return RedirectToAction("Index", "Home");
        }
        //**************************************************************************
        [AllowAnonymous]
        public IActionResult AccessDenied()
        {
            return View();
        }
        //**************************************************************************


    }
}