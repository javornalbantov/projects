﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    public class ChangeLanguageController : Controller
    {
        private IHttpContextAccessor http;
        public ChangeLanguageController(IHttpContextAccessor access)
        {
            this.http = access;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Update(TranslateUIModel sender,string setlanguage)
        {
            ManageCookie cookie = new ManageCookie(this.http);
            cookie.Set(ManageCookie.COOKIE_LANGUAGE, cookie.CookieFromCulture(setlanguage), 60);
            return Redirect(sender.ReturnUrl);
        }
    }
}