﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Server.IIS.Core;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Logging.Abstractions;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    [Authorize(Roles = consts.AdminLoginRole)]
    public class AdminUsersController : Controller
    {
        private UserManager<AppUser> manager = null;
        private ICountryReader country_reader = null;
        private IUserValidator<AppUser> user_validator = null;
        private IPasswordValidator<AppUser> pass_validator = null;
        private IPasswordHasher<AppUser> pass_maker = null;
        private RoleManager<IdentityRole> role_manager = null;
        //*********************************************************************************************
        public AdminUsersController(
            UserManager<AppUser> aManager,
            ICountryReader aCountryReader,
            IUserValidator<AppUser> aUserValidator,
            IPasswordValidator<AppUser> aPassValidator,
            IPasswordHasher<AppUser> aPassMaker,
            RoleManager<IdentityRole> aRoleManager
            )
        {
            this.role_manager = aRoleManager;
            this.manager = aManager;
            this.country_reader = aCountryReader;
            this.user_validator = aUserValidator;
            this.pass_validator = aPassValidator;
            this.pass_maker = aPassMaker;
        }
        //*********************************************************************************************
        
        public IActionResult Index(int? id,string element_filter)
        {
            IEnumerable<AppUser> list = this.manager.Users.ToList<AppUser>().
                Where(x=>x.Email.FilterLike(element_filter)).
                OrderBy(x => x.UserName);
            
            int element_count = list.Count();

            AdminUsersPager data = new AdminUsersPager();
            data.Details(id, element_count, element_filter);

            var elements = list.
                Skip((data.page - 1) * data.page_size).
                Take(data.page_size);

            ViewBag.filter = data;

            return View(elements);
        }
        
        
        //*********************************************************************************************
        
        public IActionResult Create()
        {
            return View(LocalAppUser.Empty(this.country_reader));
        }
        //*********************************************************************************************
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(LocalAppUser sender)
        {
            if (ModelState.IsValid)
            {

                AppUser db_user = sender.ToAppUser();
                IdentityResult db_result =
                await this.manager.CreateAsync(db_user, sender.Password);

                if (db_result.Succeeded)
                {
                    //прибавя се като обикновен потребител...
                    IdentityRole users_role = await this.role_manager.FindByNameAsync(consts.UsersLoginRole);
                    if (users_role != null)
                    {
                        await this.manager.AddToRoleAsync(db_user, users_role.Name);
                    }
                    return RedirectToAction("Index", "AdminUsers");
                }
                else
                {
                    ModelState.AddMultipleErrors(db_result.Errors);

                    sender.CountryOptions = this.country_reader.Get();
                    return View("Create", sender);
                }

            }
            else
            {
                sender.CountryOptions = this.country_reader.Get();
                return View("Create", sender);
            }
        }
        //*********************************************************************************************
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(string id)
        {
            AppUser key = await this.manager.FindByIdAsync(id);
            if (key != null)
            {
                await this.manager.DeleteAsync(key);
            }
            return RedirectToAction("Index", "AdminUsers");
        }


        //*********************************************************************************************
        public async Task<IActionResult> Details(string id, int pageid,string filter)
        {
            AppUser key = await this.manager.FindByIdAsync(id);
            if (key != null)
            {

                AdminUsersPager data = new AdminUsersPager();
                data.Details(pageid, 0, filter);

                ViewBag.filter = data;
                
                return View(key.ToLocalAppUser(this.country_reader));
            }
            else
            {
                return NotFound();
            }
        }

        //*********************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public async Task<IActionResult> Details(LocalAppUser sender, int pageid, string filter)
        {
            AdminUsersPager data = new AdminUsersPager();
            data.Details(pageid, 0, filter);

            ViewBag.filter = data;

            if (ModelState.IsValid)
            {

                AppUser create_user = await this.manager.FindByIdAsync(sender.ID);
                if (create_user != null)
                {
                    sender.Write(create_user);
                    IdentityResult result_password = await this.pass_validator.ValidateAsync(this.manager, create_user, sender.Password);
                    IdentityResult result_username = await this.user_validator.ValidateAsync(this.manager, create_user);
                    if (result_username.Succeeded == false)
                    {
                        ModelState.AddMultipleErrors(result_username.Errors);
                    }
                    if (result_password.Succeeded == false)
                    {
                        ModelState.AddMultipleErrors(result_password.Errors);
                    }
                    if (ModelState.ErrorCount == 0)
                    {
                        create_user.PasswordHash = this.pass_maker.HashPassword(create_user, sender.Password);
                        await this.manager.UpdateAsync(create_user);
                        return RedirectToAction("Index", "AdminUsers",new { id=pageid,element_filter=filter});
                    }
                    else
                    {
                        sender.CountryOptions = this.country_reader.Get();
                        return View(sender);
                    }
                }
                else
                    return BadRequest();

            }
            else
            {
                sender.CountryOptions = this.country_reader.Get();
                return View(sender);
            }
        }
             
        //*********************************************************************************************
        public async Task<IActionResult> Roles(string id,int pageid,string filter)
        {
            AdminUsersPager data = new AdminUsersPager();
            data.Details(pageid, 0, filter);

            ViewBag.filter = data;

            ExtractRoles extract = new ExtractRoles();
            await extract.Read(this.role_manager, this.manager, id);
            IEnumerable<UserRoleItem> elements = extract.GetItems().OrderBy(x=>x.RoleName);
            return View(elements);

        }
        //*********************************************************************************************
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Roles(IEnumerable<UserRoleItem> sender, int pageid,string filter)
        {
            ExtractRoles extract = new ExtractRoles();
            await extract.Write(sender, this.manager);
            return RedirectToAction("Index", "AdminUsers", new { id = pageid,element_filter = filter });
        }
        //*********************************************************************************************
    }
}