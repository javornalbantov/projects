﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebApplication16.Models;

namespace WebApplication16.Controllers
{
    [Authorize(Roles = consts.UsersLoginRole)]
    public class ManageShopMenuController : Controller
    {
        private ISessionReader mCurrentOrder;
        //**************************************************************************************************************
        public ManageShopMenuController(ISessionReader order)
        {
            this.mCurrentOrder = order;
            
        }
        //**************************************************************************************************************
        public IActionResult Index()
        {
            return View(this.mCurrentOrder);
        }
        //**************************************************************************************************************
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Reset()
        {
            this.mCurrentOrder.ClearAll();
            return RedirectToAction("Index", "ManageShopMenu");
        }
        //**************************************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Insert(ProductBridge sender,int ProductQuantity,string returnUrl)
        {
            
            this.mCurrentOrder.Insert(Convert.ToInt32(sender.ID), ProductQuantity);
            return Redirect(returnUrl);
        }
        //**************************************************************************************************************
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Update(int ProductID, int Quantity)
        {
            bool is_delete = Request.Form.ContainsKey("btnRemove");
            bool is_update = Request.Form.ContainsKey("btnUpdate");
            if (is_delete)
            {
                this.mCurrentOrder.Remove(ProductID);
            }
            else
                if (is_update)
                {
                    this.mCurrentOrder.Update(ProductID, Quantity);
                }
            
            
            return RedirectToAction("Index", "ManageShopMenu");

        }
        //**************************************************************************************************************
        public IActionResult OrderAccept()
        {
            return View();
        }
        //**************************************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout()
        {
            await this.mCurrentOrder.Checkout();
            return RedirectToAction("OrderAccept", "ManageShopMenu");
        }
        //**************************************************************************************************************
    }
}