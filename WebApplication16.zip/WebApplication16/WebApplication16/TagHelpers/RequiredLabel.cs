﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.TagHelpers
{
    [HtmlTargetElement("label",Attributes ="reqstar")]
    public class RequiredLabel:TagHelper
    {

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            TagBuilder tstar = new TagBuilder("span");
            tstar.Attributes.Add("style", "font-weight:bold;display:inline-block;margin-left:10px;color:red;font-size:20px;");
            tstar.InnerHtml.Append("*");

            output.PostContent.AppendHtml(tstar);


        }
    }
}
