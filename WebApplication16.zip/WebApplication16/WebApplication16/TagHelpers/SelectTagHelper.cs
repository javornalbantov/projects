﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.TagHelpers
{
    [HtmlTargetElement("select",Attributes ="default-text")]
    public class SelectTagHelper:TagHelper
    {
        public string DefaultText { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            TagBuilder toption = new TagBuilder("option");
            toption.Attributes.Add("value", "");
            toption.InnerHtml.Append(this.DefaultText);

            output.PreContent.SetHtmlContent(toption);

        }
    }
}
