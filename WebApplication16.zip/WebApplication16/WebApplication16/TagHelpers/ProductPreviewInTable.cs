﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication16.TagHelpers
{
    [HtmlTargetElement("div",Attributes ="preview-image")]
    public class ProductPreviewInTable:TagHelper
    {
        public string PreviewImage { get; set; }

        public int PreviewSize { get; set; }

        

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            List<string> css = new List<string>();
            css.Add($"display:inline-block;width:{Convert.ToInt32(this.PreviewSize*1.6F)}px;height:{this.PreviewSize}px");
            css.Add("background-position:center center");
            css.Add("background-size:cover");
            css.Add($"background-image:url('{this.PreviewImage}')");
            output.Attributes.Add("style", string.Join(";",css.ToArray()));
        }
    }
}
