﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebApplication22.DataTableModels
{
    public partial class WEBSITELISTContext : DbContext
    {
        public WEBSITELISTContext()
        {
        }

        public WEBSITELISTContext(DbContextOptions<WEBSITELISTContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ActiveSites> ActiveSites { get; set; }
        public virtual DbSet<Category> Category { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ActiveSites>(entity =>
            {
                entity.ToTable("ACTIVE_SITES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CategoryId).HasColumnName("CATEGORY_ID");

                entity.Property(e => e.Homepage)
                    .IsRequired()
                    .HasColumnName("HOMEPAGE")
                    .HasMaxLength(100);

                entity.Property(e => e.LoginPassword)
                    .IsRequired()
                    .HasColumnName("LOGIN_PASSWORD")
                    .HasMaxLength(50);

                entity.Property(e => e.LoginUsername)
                    .IsRequired()
                    .HasColumnName("LOGIN_USERNAME")
                    .HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("NAME")
                    .HasMaxLength(200);

                entity.Property(e => e.SoftDelete).HasColumnName("SOFT_DELETE");

                entity.Property(e => e.Url)
                    .IsRequired()
                    .HasColumnName("URL")
                    .HasMaxLength(500);

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.ActiveSites)
                    .HasForeignKey(d => d.CategoryId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK__ACTIVE_SI__CATEG__1273C1CD");
            });

            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("CATEGORY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("NAME")
                    .HasMaxLength(100);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
