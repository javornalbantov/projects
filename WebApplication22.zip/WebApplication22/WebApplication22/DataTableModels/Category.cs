﻿using System;
using System.Collections.Generic;

namespace WebApplication22.DataTableModels
{
    public partial class Category
    {
        public Category()
        {
            ActiveSites = new HashSet<ActiveSites>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<ActiveSites> ActiveSites { get; set; }
    }
}
