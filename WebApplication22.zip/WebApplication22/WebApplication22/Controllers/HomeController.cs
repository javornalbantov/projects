﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication22.DataTableModels;
using WebApplication22.Models;

namespace WebApplication22.Controllers
{
    public class HomeController : Controller
    {
        
        private IConnectDatabase db = null;
        
        //***********************************************************************************************************
        public HomeController(IConnectDatabase context)
        {
            this.db = context;
        }
        //***********************************************************************************************************
        public IActionResult Index()
        {
            return View(WebSiteItem.Default(this.db));
        }
        //***********************************************************************************************************
        public IActionResult List(int? page, int? order, int? column)
        {
            ElementPager sorter;

            var active_sites = this.db.GetSites(page, order, column, out sorter);
            
            ViewBag.sorter = sorter;
            
            return View(active_sites);
        }
        //***********************************************************************************************************
        public IActionResult Details(int? id,int page,int order,int column)
        {
            
            
            WebSiteItem result = this.db.Details(id);
            if (result == null)
            {
                return BadRequest();
            }
            else
            {
                ElementPager sorter = new ElementPager();
                sorter.PageIndex = sorter.DefaultPageIndex(page);
                sorter.PageSort = sorter.DefaultSortOrder(order);
                sorter.Column = sorter.DefaultSortableColumn(column);

                ViewBag.sorter = sorter;

                return View(result);
            }
        }
        //***********************************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Details(WebSiteItem sender, int page, int order, int column)
        {
            if (ModelState.IsValid)
            {
                this.db.Update(sender);
                return RedirectToAction(
                    "List", 
                    "Home",
                    new
                    {
                         page = page,
                         order = order,
                         column = column 
                    }
                    );
            }
            else
            {
                sender.CategoryList = this.db.GetCategory();
                return View(sender);
            }
        }
        //***********************************************************************************************************
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Index(WebSiteItem sender)
        {
            if (ModelState.IsValid)
            {
                this.db.Insert(sender);
                return RedirectToAction("List", "Home");
            }
            else
            {
                sender.CategoryList = this.db.GetCategory();
                return View(sender);
            }
        }
        //***********************************************************************************************************
        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Delete(int id,int page,int order,int column)
        {
            
            this.db.Delete(id);
            ElementPager pager = new ElementPager();
            int? stay_on_page = pager.StayOnPage(page, this.db.GetSites());
            
            if (stay_on_page.HasValue)
            {
                return RedirectToAction(
                    "List",
                    "Home",
                    new
                    {
                        page = stay_on_page,
                        order = order,
                        column = column
                    }
                    );
            }
            else
            {
                return RedirectToAction(
                    "List",
                    "Home");
            }
        }

        //***********************************************************************************************************

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        //***********************************************************************************************************
    }
}
