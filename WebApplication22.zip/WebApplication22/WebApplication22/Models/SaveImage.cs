﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace WebApplication22.Models
{
    public class SaveImage:ISaveImage
    {
        private IWebHostEnvironment host = null;

        public SaveImage(IWebHostEnvironment web_host)
        {
            this.host = web_host;
        }

        
        string ISaveImage.SuggestName(string filename)
        {
            Guid nextname = Guid.NewGuid();
            string result = string.Format("{0}{1}", nextname.ToString(), Path.GetExtension(filename));
            return result;
        }

        string ISaveImage.GetAbsolutePath(string upload_filename)
        {
            var result = string.Format("{0}/{1}/{2}",
                this.host.WebRootPath,
                consts.UPLOAD_IMAGE_FOLDER,
                upload_filename);
            return result;
        }

        void ISaveImage.SaveImage(IFormFile uploader, string upload_filename)
        {

            var full_path = (this as ISaveImage).GetAbsolutePath(upload_filename);
            using (FileStream fs = File.OpenWrite(full_path))
            {
                uploader.CopyTo(fs);
                 
            }
            
        }
    }


    
}
