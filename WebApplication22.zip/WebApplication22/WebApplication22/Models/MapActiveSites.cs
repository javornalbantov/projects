﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public class MapActiveSites
    {
        public string Name { get; set; }
        public string Url { get; set; }

        public int ID { get; set; }

        public string Category { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public string Homepage { get; set; }
    }
}
