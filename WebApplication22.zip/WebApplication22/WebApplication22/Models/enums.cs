﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public enum SortType:int
    {
        Ascending =2,
        Descending = 1,
        None = 0
    }

    public enum SortableColumn
    {
        Name,
        Url,
        Category,
        Username,
        Password
    }
}
