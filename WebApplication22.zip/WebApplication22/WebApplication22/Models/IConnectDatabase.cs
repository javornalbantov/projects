﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public interface IConnectDatabase
    {
        IEnumerable<MapCategory> GetCategory();

        

        void Insert(WebSiteItem sender);

        WebSiteItem Details(int? id);

        void Update(WebSiteItem sender);

        void Delete(int id);

        IEnumerable<MapActiveSites> GetSites
            (
                int? page, int? order, int? column,
                out ElementPager sorter
            );

        IEnumerable<MapActiveSites> GetSites();


    }
}
