﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public class consts
    {
        public const string UPLOAD_IMAGE_FOLDER = "images";
        public const int max_width = 320;
        public const int max_height = 240;

        public static readonly string[] file_extension = new string[] { "*.jpeg", "*.jpg", "*.png" };

        public const string JpegMimeType = "image/png, image/jpeg";

        public const string UpArrow = "&#8593;";
        public const string DownArrow = "&#8595;";
        public const int on_page = 3;
    }
}
