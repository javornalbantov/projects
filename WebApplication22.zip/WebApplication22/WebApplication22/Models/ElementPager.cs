﻿using Microsoft.AspNetCore.Server.IIS.Core;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Razor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Security.AccessControl;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public class ElementPager
    {
        


        public int PageIndex { get; set; }

        public SortType PageSort { get; set; }

        public SortableColumn Column { get; set; }

        public int TotalPages { get; set; }
        //*******************************************************************************************************************
        public bool Empty()
        {
            return this.TotalPages == 0;
        }
        //*******************************************************************************************************************
        public string SelectedClass(bool is_selected, string class_selected, string class_deselected)
        {
            string result = class_deselected;
            if (is_selected)
            {
                result = class_selected;
            }
            return
                result;
        }
        //*******************************************************************************************************************
        public string SortedColumnTitle(SortableColumn column_name,string title)
        {
            string result = title;//nqma sortirane...

            if (this.Column == column_name)
            {
                result = string.Format("{0} {1}", title, this.SortGlyph());
            }

            return result;
        }
        //*******************************************************************************************************************
        public int NextSortDirection(SortableColumn current_column)
        {
            int result = this.SortOrderToInt
                (
                this.NextSortDirection(this.PageSort)
                );
            if (this.Column != current_column)
            {
                //избираме колона, различна от вече сортираната...
                result = this.SortOrderToInt(SortType.Ascending);
            }
            return result;
        }

        //*******************************************************************************************************************
        private SortType NextSortDirection(SortType sort_type)
        {
            SortType result = SortType.None;

            switch (sort_type)
            {
                case SortType.Ascending:
                    result = SortType.Descending;
                    break;
                case SortType.Descending:
                    result = SortType.None;
                    break;
                case SortType.None:
                    result = SortType.Ascending;
                    break;
            }

            return result;
        }

        //*******************************************************************************************************************
        private string SortGlyph()
        {
            string result = "";
            switch (this.PageSort)
            {
                case SortType.Ascending:
                    result = consts.UpArrow;
                    break;
                case SortType.Descending:
                    result = consts.DownArrow;
                    break;
            }
            return result;
        }
        //*******************************************************************************************************************
        public int? StayOnPage(int current_page, IEnumerable<MapActiveSites> active_sites)
        {
            int? result = null;

            if (active_sites.Count() == 0)
            {
                result = null;
            }
            else
            {
                int elements_on_page = active_sites.
                    Skip((current_page - 1) * consts.on_page).
                    Take(consts.on_page).Count();
                if (elements_on_page > 0)
                {
                    //ако има елементи на страница current_page...
                    result = current_page;
                }
                else
                {
                    //...елементите са свършили, отиди на последна страница
                    result = this.PageCount(active_sites.Count());
                }
            }
            return result;
        }
        //*******************************************************************************************************************
        public int PageCount(int element_count)
        {
            int result = (int)Math.Ceiling(element_count / (float)consts.on_page);
            return result;
        }
        //*******************************************************************************************************************
        public int SortOrderToInt(SortType sort_order)
        {
            return (int)sort_order;
        }
        //*******************************************************************************************************************
        public int SortColumnToInt(SortableColumn key)
        {
            return (int)key;
        }
        //*******************************************************************************************************************
        public int DefaultPageIndex(int? page_index)
        {
            int result = page_index ?? 1;
            return result;
        }
        //*******************************************************************************************************************
        public SortType DefaultSortOrder(int? key)
        {
            SortType result = SortType.Ascending;
            if (key.HasValue)
            {
                switch (key)
                {
                    case (int)SortType.Ascending:
                        result = SortType.Ascending;
                        break;
                    case (int)SortType.Descending:
                        result = SortType.Descending;
                        break;

                }
            }
            return result;
        }
        //*******************************************************************************************************************
        public SortableColumn DefaultSortableColumn(int? key)
        {
            SortableColumn result = SortableColumn.Name;//по дефолт сортирани по име

            if (key.HasValue)
            {
                switch (key)
                {
                    case (int)SortableColumn.Category:
                        result = SortableColumn.Category;
                        break;
                    case (int)SortableColumn.Name:
                        result = SortableColumn.Name;
                        break;
                    case (int)SortableColumn.Password:
                        result = SortableColumn.Password;
                        break;
                    case (int)SortableColumn.Url:
                        result = SortableColumn.Url;
                        break;
                    case (int)SortableColumn.Username:
                        result = SortableColumn.Username;
                        break;
                }
            }

            return result;

        }
        //*******************************************************************************************************************
        public static ElementPager FromViewBag(dynamic sender)
        {
            return sender as ElementPager;
        }
        //*******************************************************************************************************************
    }
}
