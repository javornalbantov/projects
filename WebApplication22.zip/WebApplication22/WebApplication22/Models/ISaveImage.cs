﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public interface ISaveImage
    {

        void SaveImage(IFormFile uploader, string upload_filename);

        string SuggestName(string filename);

        string GetAbsolutePath(string filename);
    }
}
