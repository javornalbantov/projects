﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public class RequiredUploadAttribute : ValidationAttribute
    {
        private readonly string _comparisonProperty;
        //**************************************************************************************************
        public RequiredUploadAttribute(string compareTo)
        {
            this._comparisonProperty = compareTo;
        }
        //**************************************************************************************************
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string preview_image_file =
                (string)(validationContext.
                ObjectType.
                GetProperty(_comparisonProperty).
                GetValue(validationContext.ObjectInstance));

            if (string.IsNullOrEmpty(preview_image_file))
            {
                //nov zapis...
                IFormFile k = value as IFormFile;
                if (k == null)
                {
                    return new ValidationResult(this.ErrorMessage);
                }
                else
                {
                    bool allowed_ext = 
                        k.FileName.AllowExtension(consts.file_extension);
                    if (allowed_ext)
                    {
                        return ValidationResult.Success;
                    }
                    else
                    {
                        return new ValidationResult(this.ErrorMessage);
                    }
                }

            }
            else
            {
                IFormFile k = value as IFormFile;
                if (k == null)
                {
                    //..работим със старата картинка...
                    return ValidationResult.Success;
                }
                else
                {
                    //... проверяваме какво е качено...
                    bool allowed_ext =
                        k.FileName.AllowExtension(consts.file_extension);
                    if (allowed_ext)
                    {
                        return ValidationResult.Success;
                    }
                    else
                    {
                        return new ValidationResult(this.ErrorMessage);
                    }
                }
            }
        }
    }
    //**********************************************************************************************************************

}
