﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplication22.DataTableModels;

namespace WebApplication22.Models
{
    public class WebSiteItem
    {
        public int ID { get; set; }
        //**********************************************************************************
        [Required(AllowEmptyStrings = false, ErrorMessage = "ErrorWebSiteName")]
        [Display(Name = "DisplayWebSiteName")]
        [MaxLength(200)]
        
        public string Name { get; set; }
        //**********************************************************************************

        [MaxLength(500)]
        [Required(AllowEmptyStrings = false, ErrorMessage = "ErrorUrl")]
        [Display(Name = "DisplayUrl")]
        public string Url { get; set; }
        //**********************************************************************************
        [Required(ErrorMessage = "ErrorCategory")]
        [Display(Name = "DisplayCategory")]
        public int? CategoryID { get; set; }
        //**********************************************************************************
        public IEnumerable<MapCategory> CategoryList { get; set; }

        //**********************************************************************************
        [Display(Name= "DisplayUploadImage")]
        [RequiredUpload(nameof(WebSiteItem.ImageFileName),ErrorMessage = "ErrorUploadFile")]
        public IFormFile UploadedFile { get; set; }
        //**********************************************************************************
        [Display(Name = "DisplayCurrentImage")]
        public string ImageFileName { get; set; }

        //**********************************************************************************
        public LoginDetails WebsiteLogin { get; set; }
        //**********************************************************************************
        public string ToImgTag()
        {
            IRelativeImagePath reader = new RelativeImagePath();
            return reader.FilePath(this.ImageFileName);
        }
        //**********************************************************************************
        public SelectList ToSelectList()
        {
            SelectList result = new SelectList(this.CategoryList, nameof(MapCategory.ID), nameof(MapCategory.Name));
            return result;
        }
        //**********************************************************************************
        public bool IsNewRecord()
        {
            return string.IsNullOrEmpty(this.ImageFileName);
        }
        //**********************************************************************************
        public static WebSiteItem Default(IConnectDatabase context)
        {
            WebSiteItem result = new WebSiteItem()
            {
                ID = 0,
                Name = string.Empty,
                Url = string.Empty,
                CategoryID = null,
                CategoryList = context.GetCategory(),
                UploadedFile = null,
                ImageFileName = string.Empty,
                WebsiteLogin = new LoginDetails()
                {
                    Password = string.Empty,
                    UserName = string.Empty
                }

            };
            return result;
        }
        //**********************************************************************************
    }

}
