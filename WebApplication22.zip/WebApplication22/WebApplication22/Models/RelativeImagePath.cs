﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public class RelativeImagePath : IRelativeImagePath
    {
        string IRelativeImagePath.FilePath(string filename)
        {
            return string.Format("/{0}/{1}", consts.UPLOAD_IMAGE_FOLDER, filename);
        }
    }
}
