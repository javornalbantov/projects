﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public class SupportedLanguages
    {
        private List<CultureInfo> data = null;
        //*********************************************************************************
        public string GetDefault()
        {
            return "bg-bg";
        }
        //*********************************************************************************
        public List<CultureInfo> GetLanguages()
        {
            return this.data;
        }
        //*********************************************************************************
        public SupportedLanguages()
        {
            this.data = new List<CultureInfo>
            {
                new CultureInfo("en-US"),
                new CultureInfo("bg-bg"),
            };
        }
        //*********************************************************************************
    }
}
