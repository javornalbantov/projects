﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Localization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public static class MethodExtensions
    {
        //**********************************************************************************************************************
        public static IEnumerable<MapActiveSites> OrderByDescColumn(this IEnumerable<MapActiveSites> sender, SortableColumn column)
        {
            IEnumerable<MapActiveSites> result = sender;
            switch (column)
            {
                case SortableColumn.Category:
                    result = sender.OrderByDescending(x => x.Category.ToUpper());
                    break;
                case SortableColumn.Name:
                    result = sender.OrderByDescending(x => x.Name.ToUpper());
                    break;
                case SortableColumn.Password:
                    result = sender.OrderByDescending(x => x.Password.ToUpper());
                    break;
                case SortableColumn.Url:
                    result = sender.OrderByDescending(x => x.Url.ToUpper());
                    break;
                case SortableColumn.Username:
                    result = sender.OrderByDescending(x => x.Password.ToUpper());
                    break;
            }
            return result;
        }

        //**********************************************************************************************************************
        public static IEnumerable<MapActiveSites> OrderByColumn(this IEnumerable<MapActiveSites> sender, SortableColumn column)
        {
            IEnumerable<MapActiveSites> result = sender;
            switch (column)
            {
                case SortableColumn.Category:
                    result = sender.OrderBy(x => x.Category.ToUpper());
                    break;
                case SortableColumn.Name:
                    result = sender.OrderBy(x => x.Name.ToUpper());
                    break;
                case SortableColumn.Password:
                    result = sender.OrderBy(x => x.Password.ToUpper());
                    break;
                case SortableColumn.Url:
                    result = sender.OrderBy(x => x.Url.ToUpper());
                    break;
                case SortableColumn.Username:
                    result = sender.OrderBy(x => x.Password.ToUpper());
                    break;
            }
            return result;
        }
        //**********************************************************************************************************************
        public static bool AllowExtension(this string filename, string[] extensions)
        {
            string extract = string.Format("*{0}", Path.GetExtension(filename));

            bool result = extensions.Any(x => { return x.ToLower() == extract.ToLower(); });

            return result;
        }
        //**********************************************************************************************************************

        public static void LoadLanguages(this IApplicationBuilder sender)
        {
            SupportedLanguages list_language = new SupportedLanguages();

            var localizationOptions = new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture(list_language.GetDefault()),
                SupportedCultures = list_language.GetLanguages(),
                SupportedUICultures = list_language.GetLanguages()
            };
            localizationOptions.RequestCultureProviders
                .OfType<CookieRequestCultureProvider>()
                .First().CookieName = "UserCulture";
            sender.UseRequestLocalization(localizationOptions);
        }
        //**********************************************************************************************************************
    }
}
