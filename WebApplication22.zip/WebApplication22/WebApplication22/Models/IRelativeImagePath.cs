﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Models
{
    public interface IRelativeImagePath
    {
        string FilePath(string filename);
    }

   
}
