﻿using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Razor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplication22.DataTableModels;

namespace WebApplication22.Models
{
    public class ConnectDatabase : IConnectDatabase
    {
        private WEBSITELISTContext context = null;
        private ISaveImage save_image = null;
        private IRelativeImagePath image_path_reader = null;
        //************************************************************************************************************
        public ConnectDatabase(WEBSITELISTContext db, ISaveImage aSaveImage, IRelativeImagePath aImagePathReader)
        {
            this.context = db;
            this.save_image = aSaveImage;
            this.image_path_reader = aImagePathReader;
        }
        //************************************************************************************************************
        IEnumerable<MapActiveSites> IConnectDatabase.GetSites()
        {
            IEnumerable<MapActiveSites> result = (from site in this.context.ActiveSites
                                                  join category in this.context.Category
                                                  on site.CategoryId equals category.Id
                                                  where site.SoftDelete == 0
                                                  select
                                                  new MapActiveSites()
                                                  {

                                                      Name = site.Name,
                                                      Url = site.Url,
                                                      ID = site.Id,
                                                      Category = category.Name,
                                                      Username = site.LoginUsername,
                                                      Password = site.LoginPassword,
                                                      Homepage = this.image_path_reader.FilePath(site.Homepage)


                                                  }

                                               ).
                                               ToList<MapActiveSites>();
            return result;
        }
        //************************************************************************************************************
        IEnumerable<MapActiveSites> IConnectDatabase.GetSites
            (
                int? page, int? order, int? column,
                out ElementPager sorter
            )
        {
            
            IEnumerable<MapActiveSites> result = (this as IConnectDatabase).GetSites();
            
            sorter = new ElementPager();
            sorter.PageIndex = sorter.DefaultPageIndex(page);
            sorter.TotalPages = sorter.PageCount(result.Count());

            sorter.Column = sorter.DefaultSortableColumn(column);
            sorter.PageSort = sorter.DefaultSortOrder(order);
            

            switch (sorter.PageSort)
            {
                case SortType.Ascending:
                    result = result.OrderByColumn(sorter.Column);
                    break;
                case SortType.Descending:
                    result = result.OrderByDescColumn(sorter.Column);
                    break;
            }


            result = result.Skip((sorter.PageIndex - 1) * consts.on_page).Take(consts.on_page);

            return result;
            

             
        }
        //************************************************************************************************************
        IEnumerable<MapCategory> IConnectDatabase.GetCategory()
        {
            IEnumerable<MapCategory> result = this.context.Category.OrderBy(x => x.Name).Select
                (
                x => new MapCategory()
                {
                    ID = x.Id,
                    Name = x.Name
                }
                ).ToList();
            return result;
        }
        //************************************************************************************************************
        WebSiteItem IConnectDatabase.Details(int? id)
        {
            WebSiteItem result = null;
            if (id.HasValue)
            {
                if (this.context.ActiveSites.Any(x => x.Id == id))
                {
                    ActiveSites element = this.context.ActiveSites.Where(x => x.Id == id).First();
                    result = new WebSiteItem()
                    {
                        ID = element.Id,
                        Name = element.Name,
                        Url = element.Url,
                        CategoryID = element.CategoryId,
                        CategoryList = (this as IConnectDatabase).GetCategory(),
                        UploadedFile = null,
                        ImageFileName = element.Homepage,
                        WebsiteLogin = new LoginDetails()
                        {
                            Password = element.LoginPassword,
                            UserName = element.LoginUsername
                        }
                    };
                }
            }
            return result;
        }
        //************************************************************************************************************
        void IConnectDatabase.Insert(WebSiteItem sender)
        {
            string save_as = this.save_image.SuggestName(sender.UploadedFile.FileName);
            this.save_image.SaveImage(sender.UploadedFile, save_as);
            ActiveSites item = new ActiveSites()
            {
                Name = sender.Name.Trim(),
                Url = sender.Url.Trim(),
                CategoryId = sender.CategoryID,
                Homepage = save_as,
                LoginUsername = sender.WebsiteLogin.UserName.Trim(),
                LoginPassword = sender.WebsiteLogin.Password.Trim(),
                SoftDelete = 0
            };
            this.context.ActiveSites.Add(item);
            this.context.SaveChanges();
        }
        
        

        //************************************************************************************************************
        void IConnectDatabase.Update(WebSiteItem sender)
        {

            ActiveSites element = this.context.ActiveSites.Where(x => x.Id == sender.ID).First();
            element.Name = sender.Name.Trim();
            element.Url = sender.Url.Trim();
            element.CategoryId = sender.CategoryID;
            if (sender.UploadedFile != null)
            {

                this.save_image.SaveImage(sender.UploadedFile, element.Homepage);

            }
            element.LoginUsername = sender.WebsiteLogin.UserName.Trim();
            element.LoginPassword = sender.WebsiteLogin.Password.Trim();
            this.context.SaveChanges();

        }
        //************************************************************************************************************
        void IConnectDatabase.Delete(int id)
        {
            if (this.context.ActiveSites.Any(x => x.Id == id))
            {
                var element = this.context.ActiveSites.Where(x => x.Id == id).First();
                element.SoftDelete = 1;
                this.context.SaveChanges();
            }
        }
        //************************************************************************************************************
    }
}
