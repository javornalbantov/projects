﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace WebApplication22.TagHelpers
{
    [HtmlTargetElement("label",Attributes ="reqstar")]
    public class RequiredLabel:TagHelper
    {
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            TagBuilder tb = new TagBuilder("label");
            tb.InnerHtml.Append("*");
            tb.Attributes.Add("style", "display:inline;margin-left:10px;font-weight:bold;color:red;");

            output.PostContent.AppendHtml(tb);

        }

    }
}
