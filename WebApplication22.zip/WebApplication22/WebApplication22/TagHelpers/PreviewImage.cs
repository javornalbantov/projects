﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.TagHelpers
{
    [HtmlTargetElement("div",Attributes ="file-image")]
    public class PreviewImage:TagHelper
    {
        public int Width { get; set; }

        public int Height { get; set; }

        public string FileImage { get; set; }


        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.TagMode = TagMode.StartTagAndEndTag;
            List<string> attr_image = new List<string>();
            attr_image.Add(string.Format("{0} : {1}", "display", "inline-block"));
            attr_image.Add(string.Format("{0} : {1}", "width", $"{this.Width}px"));
            attr_image.Add(string.Format("{0} : {1}", "height", $"{this.Height}px"));
            attr_image.Add(string.Format("{0} : {1}", "background-position", "center center"));
            attr_image.Add(string.Format("{0} : {1}", "background-size", "cover"));
            attr_image.Add(string.Format("{0} : {1}", "background-image", $"url('{this.FileImage}?preview={DateTime.Now.ToString()}')"));
            attr_image.Add(string.Format("{0} : {1}", "border", "1px solid black"));

            output.Attributes.Add("style", string.Join("; ", attr_image.ToArray()));


        }
    }
}
