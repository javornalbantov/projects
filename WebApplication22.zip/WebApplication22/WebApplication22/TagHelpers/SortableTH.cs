﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace WebApplication22.TagHelpers
{
    [HtmlTargetElement("th",Attributes ="page, sort-order")]
    public class SortableTH:TagHelper
    {

        //**********************************************************************************************************************************
        public int Page { get; set; }
        //**********************************************************************************************************************************
        public int SortOrder { get; set; }
        //**********************************************************************************************************************************
        public int SortColumn { get; set; }
        //**********************************************************************************************************************************
        public string InnerText { get; set; }
        //**********************************************************************************************************************************
        private IUrlHelperFactory html_link = null;
        //**********************************************************************************************************************************
        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext CurrentContext { get; set; }
        //**********************************************************************************************************************************
        public SortableTH(IUrlHelperFactory aHtmlLink)
        {
            this.html_link = aHtmlLink;
        }
        //**********************************************************************************************************************************
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            var url = this.html_link.GetUrlHelper(this.CurrentContext);

            var link = url.Action("List", "Home",
                new
                {
                    page = this.Page,
                    order = this.SortOrder,
                    column = this.SortColumn
                }
                );

            TagBuilder tb = new TagBuilder("a");
            tb.TagRenderMode = TagRenderMode.Normal;
            tb.Attributes.Add("href", link);
            tb.Attributes.Add("style", "display:block;");
            tb.InnerHtml.SetHtmlContent(this.InnerText);
            output.Content.SetHtmlContent(tb);
        }
        //**********************************************************************************************************************************
    }
}
